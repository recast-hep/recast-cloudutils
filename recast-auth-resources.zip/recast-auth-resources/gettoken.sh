kinit lheinric@CERN.CH -k -t "$(dirname $0)"/lheinric.keytab 
